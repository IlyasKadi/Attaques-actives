//Generer un packet IP qui encapsule un paquet ICMP (application d'un PING)

#include <sys/types.h>
#include <sys/socket.h>
#include <linux/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <errno.h>
#include <netdb.h>
#include <string.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <netinet/ip.h>
#include <netinet/ip_icmp.h>
#include <ctype.h>
#include <unistd.h>

unsigned short in_chksum(unsigned short *, int);

int main (int argc, char * argv[])
{
	int sock;
	int rc;
	int num;
	struct sockaddr_in addrsock_source;
        struct sockaddr_in addrsock_dest;
	struct iphdr *ip;
	struct icmphdr *icmp;
	char *packet;
	int psize;
	
	//Syntaxe : adresse
	if (argc != 4)
	{
		perror("Syntaxe : my_ping adresse-source adresse-dest taille");
		exit(1);
	}
		
	//Recuperation de la taille des données du paquet
	psize= atoi(argv[3]);
	//Création de la strucutre d'adressage
	addrsock_source.sin_addr.s_addr = inet_addr(argv[1]);// Affectation de l'adresse source
	addrsock_dest.sin_addr.s_addr = inet_addr(argv[2]);// Affectation de l'adress dest
	addrsock_source.sin_family = AF_INET;// Connection de type AF_INET
	addrsock_dest.sin_family = AF_INET;// Connection de type AF_INET
	addrsock_source.sin_port = htons(0);// Port = 0
	addrsock_dest.sin_port = htons(0);// Port = 0
		
	//Création de la socket
	sock = socket(AF_INET, SOCK_RAW, IPPROTO_RAW);
	if (sock < 0)
	{
		perror("Erreur de création de Socket en mode Raw, Verifier que vous ête administrateur");
		exit(-1);
	}
	
	//Réservation d'un espace mémoire de la taille du paquet (en tete IP + en tete ICMP + données)
	packet = malloc(sizeof(struct iphdr) + sizeof (struct icmphdr) + psize);
	ip = (struct iphdr *) packet; // l'entête IP d'abord ensuite ICMP
	icmp = (struct icmphdr *) (packet + sizeof(struct iphdr));
	// Mise à 0 de tous le bloc mémoire	
	memset(packet, 0, sizeof(struct iphdr) + sizeof(struct icmphdr) + psize);
	// Définition des champs des trames IP & ICMP
	ip->tot_len = htons(sizeof(struct iphdr) + sizeof(struct icmphdr) + psize);
	ip->ihl = 5;
	ip->version = 4;
	ip->ttl = 255;
	ip->tos = 0;
	ip->frag_off = 0;
	ip->protocol = IPPROTO_ICMP;
	ip->saddr = addrsock_source.sin_addr.s_addr;
	ip->daddr = addrsock_dest.sin_addr.s_addr;
	ip->check = in_chksum((unsigned short *)ip, sizeof(struct iphdr));
	icmp->type = 8; // pour envoyer un icmp echo request
	icmp->code = 0;
	icmp->checksum = in_chksum((unsigned short *)icmp, sizeof(struct icmphdr) + psize);
	// Envoi de la trame
	rc=sendto(sock, packet, sizeof(struct iphdr) + sizeof(struct icmphdr) + psize, 0, (struct sockaddr *)&addrsock_dest, sizeof(struct sockaddr));
	printf("Nombre de bits transmis : %d\n",rc);
	
	// Liberation de la mémoire
	free(packet);
}

unsigned short in_chksum (unsigned short *addr, int len)
{
	register int nleft = len;
	register int sum = 0;
	u_short answer = 0;

	while (nleft > 1) 
	{
		sum += *addr++;
		nleft -= 2;
	}

	if (nleft == 1) 
	{ 
		*(u_char *)(&answer) = *(u_char *)addr;
		sum += answer;
	}

	sum = (sum >> 16) + (sum + 0xffff);
	sum += (sum >> 16);
	answer = ~sum;
	return(answer);
}
