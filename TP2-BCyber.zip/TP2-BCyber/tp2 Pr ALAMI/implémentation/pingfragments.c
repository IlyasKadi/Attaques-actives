#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <errno.h>
#include <netdb.h>
#include <string.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <netinet/ip.h>
#include <netinet/ip_icmp.h>
#include <ctype.h>
#include <unistd.h>

unsigned short in_chksum(unsigned short *, int);

int main (int argc, char * argv[])
{
	//Déclaration des variables
	int sock;
	int rc;
	int num;
	int frag=8192; //ie O ==> pour indiquer que le bit MF est à 1 car le compte se fait par octet et l'offset est sur 13 bits
	struct sockaddr_in addrsock_source;
        struct sockaddr_in addrsock_dest;
	struct iphdr *ip;
	struct icmphdr *icmp;
	char *packet;
	int psize;

	//Syntaxe : adresse
	if (argc != 4)
	{
		perror("Syntaxe : nomprog adresse-source adresse-dest taille");
		exit(1);
	}
		
	//Recuperation de la taille
	psize= atoi(argv[3]);//Taille du packet
	
	if (psize < 1472)
	{
		printf("les donnée doivent être >= 1472");
		exit(-1);
	}
	
	
	//Création de la strucutre d'adressage
	addrsock_source.sin_addr.s_addr = inet_addr(argv[1]);// adresse source
	addrsock_dest.sin_addr.s_addr = inet_addr(argv[2]);// adresse dest
	addrsock_source.sin_family = AF_INET; // Connection de type AF_INET
	addrsock_dest.sin_family = AF_INET;// Connection de type AF_INET
	addrsock_source.sin_port = htons(0);// Port = 0
	addrsock_dest.sin_port = htons(0);// Port = 0
		
	//Création de la socket
	sock = socket(AF_INET, SOCK_RAW, IPPROTO_RAW);
	if (sock < 0)
	{
		perror("Erreur de création de Socket");
		exit(-1);
	}
	
	//allocation mémoire de la taille du paquet (en tete IP + en tete ICMP + données)
	packet = (char *) malloc(sizeof(struct iphdr) + sizeof (struct icmphdr) + psize);
	ip = (struct iphdr *) packet;
	icmp = (struct icmphdr *) (packet + sizeof(struct iphdr));

	// Mise à 0 de tous le bloc mémoire	
	bzero(packet, sizeof(struct iphdr) + sizeof(struct icmphdr) + psize);
	
	// Définition des champs des trames IP & ICMP
	ip->tot_len = htons(1500);
	ip->ihl = 5;
	ip->version = 4;
	ip->ttl = 255;
	ip->tos = 0;
	ip->id= htons(62500);//Identité du packet : choisi aléatoirement
	ip->protocol = IPPROTO_ICMP;
	ip->saddr = addrsock_source.sin_addr.s_addr;
	ip->daddr = addrsock_dest.sin_addr.s_addr;
	ip->check = in_chksum((unsigned short *)ip, sizeof(struct iphdr));
	icmp->type = 8;
	icmp->code = 0;

	//Envoi des trames commununes
	do
	{	
		ip->frag_off = htons(frag);				
		icmp->checksum = in_chksum((unsigned short *)icmp, sizeof(struct icmphdr) + psize);
	
		psize-=1472;//Taille des données - 1472
		frag+=(185);//185 = 1480 (1500-20) / 8 (2³ => 3 bits)

		// Envoi de la trame
		rc=sendto(sock, packet, 1500, 0, (struct sockaddr *)&addrsock_dest, sizeof(struct sockaddr));
		printf("Nombre de bits transmis : %d\n",rc);
		
	}while(psize>1472);		
	
	if (psize>0)
	{

		ip->tot_len = htons(sizeof(struct iphdr) + sizeof (struct icmphdr) +psize);	// Car on renvoie l'en tête ICMP comme donnees
		ip->frag_off = htons(frag-8192);//Car le bit More Fragment est à 0 maintenant
	
		ip->check = in_chksum((unsigned short *)ip, sizeof(struct iphdr));

		// Envoi de la trame
		rc=sendto(sock, packet, sizeof(struct iphdr) + sizeof(struct icmphdr) + psize, 0, (struct sockaddr *)&addrsock_dest, sizeof(struct sockaddr));
		printf("Nombre de bits transmis : %d\n",rc);
	}
	// Liberation de la mémoire
	// free(packet);
}

unsigned short in_chksum (unsigned short *addr, int len)
{
	register int nleft = len;
	register int sum = 0;
	u_short answer = 0;

	while (nleft > 1) 
	{
		sum += *addr++;
		nleft -= 2;
	}

	if (nleft == 1) 
	{
		*(u_char *)(&answer) = *(u_char *)addr;
		sum += answer;
	}

	sum = (sum >> 16) + (sum + 0xffff);
	sum += (sum >> 16);
	answer = ~sum;
	return(answer);
}
