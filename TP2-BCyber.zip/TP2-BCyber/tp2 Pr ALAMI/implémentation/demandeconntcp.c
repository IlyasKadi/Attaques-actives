#include <netdb.h>
#include <stdio.h>
#include <stdlib.h>
#include <netinet/tcp.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <netinet/in_systm.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/ip.h>
#include <netinet/tcp.h>
#include <unistd.h>
#include <string.h>

struct pseudohdr
{
	struct in_addr saddr;
	struct in_addr daddr;
	u_char zero;
	u_char protocol;
	u_short length;
	struct tcphdr tcpheader;
};

u_short checksum_ip(u_short * data,u_short length)
{
	register long value;
	u_short i;
	for(i=0;i<(length>>1);i++)
		value+=data[i];
	if((length&1)==1)
		value+=(data[i]<<8);
	value=(value&65535)+(value>>16);
	return(~value);
}

unsigned short checksum_tcp (unsigned short *addr, int len)
{
	register int nleft = len;
	register int sum = 0;
	u_short answer = 0;

	while (nleft > 1)
	{
		sum += *addr++;
		nleft -= 2;
	}

	if (nleft == 1)
	{
		*(u_char *)(&answer) = *(u_char *)addr;
        	sum += answer;
        }

        sum = (sum >> 16) + (sum + 0xffff);
        sum += (sum >> 16);
        answer = ~sum;
        return(answer);
}


int main(int argc,char * * argv)
{
	// Déclaration des variables
	struct sockaddr_in dest;
	struct sockaddr_in source;
	int sock;
	char buffer[40];
	struct ip * ipheader=(struct ip *) buffer;
	struct tcphdr * tcpheader=(struct tcphdr *) (buffer+sizeof(struct ip));
	struct pseudohdr pseudoheader;
	int rc;

	// Syntaxe : hote_dest port_dest hote_src
	if (argc < 4)
	{
		perror("Syntaxe : hote_dest port_dest hote_src");
		exit(-1);
	}

	//Récupération des données
	//Hote dest
	dest.sin_addr.s_addr = inet_addr(argv[1]);
	//Hote source
	source.sin_addr.s_addr = inet_addr(argv[3]);
	//Port destination
	if ((dest.sin_port = htons(atoi(argv[2]))) == 0)
	{
		perror("Dest_port inconnu");
		exit(-1);
	}

	source.sin_family=AF_INET;
	dest.sin_family=AF_INET;

	//Ouverture de la socket
	if (( sock = socket(AF_INET, SOCK_RAW, IPPROTO_RAW)) == -1)
	{
		perror("Erreur de création de Socket");
	}

	//Préparation du buffer
	bzero(buffer, sizeof(struct ip) + sizeof(struct tcphdr));

	//Packet IP
	ipheader->ip_v=4;  // Version IP
	ipheader->ip_hl=sizeof(struct ip)/4; // Longueur d'en tête IP
	ipheader->ip_len=htons(sizeof(struct ip)+sizeof(struct tcphdr));// Longeur totale
	ipheader->ip_id=htons(0xF1C); // identification : aléatoire
	ipheader->ip_ttl=255; // time to live
	ipheader->ip_src=source.sin_addr; // Source Address
	ipheader->ip_dst=dest.sin_addr; // Destination Address
	ipheader->ip_p=IPPROTO_TCP; // Protocol
	ipheader->ip_sum=checksum_tcp((u_short *)ipheader,sizeof(struct ip));// Check Sum
	
	// Packet TCP 
	tcpheader -> dest=dest.sin_port; // Port Destination
	tcpheader -> seq=htonl(0xF1C); // Numéro de Sequence
	tcpheader -> syn=1; // Flags SYN à 1
	tcpheader -> doff=0x5;// Offset Data
	tcpheader -> window=htons(2048);// Window size
	tcpheader -> source=htons(5025);// Port Source (random)

	// Construction du pseudo header
	bzero(&pseudoheader,12+sizeof(struct tcphdr));// taille du pseudo header
	pseudoheader.saddr.s_addr=source.sin_addr.s_addr;
	pseudoheader.daddr.s_addr=dest.sin_addr.s_addr;
	pseudoheader.protocol=IPPROTO_TCP;
	pseudoheader.length=htons(sizeof(struct tcphdr));
	
	// Copie de l'en-tête TCP dans le pseudo header
	tcpheader -> check= 0;
	bcopy((char *) tcpheader,(char *) &pseudoheader.tcpheader,sizeof(struct tcphdr));
	
	//Calcul du check sum TCP
	tcpheader -> check=checksum_tcp((u_short *) &pseudoheader,12+sizeof(struct tcphdr));// Checksum TCP

	// Envoi de la trame
	rc = sendto(sock, buffer, sizeof(struct ip) + sizeof (struct tcphdr), 0, (struct sockaddr *) &dest, sizeof (struct sockaddr_in)) ;

	if (rc == -1)
	{
		perror("Erreur d'envoi du message");
		return (-1);
	}
	printf("Nombre de bits envoyé : %d\n",rc);
}
